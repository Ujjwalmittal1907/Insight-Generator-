# Insight Generation

**AI-Powered Business Insight Discovery** — a capstone project that automatically
generates explainable business insights from structured datasets (CSV/Excel).

## Project Overview

Insight Generation turns a raw spreadsheet into a small set of ranked, plain-English
business insights, each backed by evidence a human can verify.

The core design principle: **Python does the math, the LLM explains the math.**
GPT-4o-mini is never shown the raw dataset and is never allowed to calculate or
invent a number — it only narrates findings that were already computed
deterministically by pandas/NumPy. A validation step then double-checks that the
narrative's numbers match the underlying finding before anything is shown to the user.

## Architecture

```
Data → Data Profiling → Data Processing → Analytics → Candidate Findings
     → Insight Scoring → LLM Explanation → Validation → Insight Dashboard
```

```
                 USER
                   |
                   v
          +-------------------+
          | File Upload       |
          | Excel / CSV       |
          +---------+---------+
                    |
                    v
          +-------------------+
          | Data Profiling    |
          | Schema / Types    |
          | Data Quality      |
          | Data Grain        |
          +---------+---------+
                    |
                    v
          +-------------------+
          | Data Processing   |
          | Cleaning          |
          | Dates             |
          | Derived Metrics   |
          +---------+---------+
                    |
                    v
          +-------------------+
          | Analytics Engine  |
          | Trend/Variance/   |
          | Contribution/     |
          | Anomaly           |
          +---------+---------+
                    |
                    v
          +-------------------+
          | Candidate Findings|
          +---------+---------+
                    |
                    v
          +-------------------+
          | Insight Scoring   |
          +---------+---------+
                    |
                    v
          +-------------------+
          | GPT-4o-mini       |
          | Explain/Recommend |
          +---------+---------+
                    |
                    v
          +-------------------+
          | Validation        |
          +---------+---------+
                    |
                    v
          +-------------------+
          | Insight Dashboard |
          +-------------------+
```

## Features

- Automated data profiling (numeric / categorical / date / ID column detection)
- Trend analysis (period-over-period change)
- Variance analysis (actual vs. target, or vs. previous period / average)
- Contribution analysis (which segments drove a total change)
- Anomaly detection (IQR method)
- Insight scoring (configurable magnitude / business impact / actionability / novelty heuristic)
- GPT-4o-mini narrative generation, constrained to a single structured finding at a time
- Insight validation (numerical, evidence, and logic checks) before display
- Streamlit dashboard with charts and insight cards

## Installation

```bash
pip install -r requirements.txt
```

## Configuration

Copy `.env.example` to `.env` and add your OpenAI API key:

```bash
cp .env.example .env
```

```
OPENAI_API_KEY=your_api_key_here
```

The key is loaded via `python-dotenv` and is never hard-coded or logged.
If no key is present, the app still runs the full analytics pipeline — narrative
generation simply falls back to showing the raw structured finding.

## Running

```bash
streamlit run app.py
```

A bundled synthetic sample dataset (`data/sample_data.csv`) lets you try the app
immediately — just check "Use bundled synthetic sample dataset" in the sidebar,
pick a metric/dimension, and click **Generate Insights**.

## Example

**Input:** a CSV with `Date, Region, Brand, Sales, Target, Calls, Patients` columns.

**Pipeline output (example):**

- Structured finding: `Region A Sales change = -600, Total change = -1000, contribution = 60%`
- LLM narrative: *"Region A is driving the sales decline. Sales in Region A declined
  by 600. Region A accounts for 60% of the overall sales decline. Investigate the
  key drivers of the decline in Region A."*
- Validation: all stated numbers (600, 60%) are confirmed present in the finding →
  insight is displayed with an Insight Score and Confidence label.

## Testing

```bash
pytest tests/test_pipeline.py -v
```

Covers: trend % growth, actual-vs-target variance, contribution %, and rejection
of numerically incorrect LLM claims.

## Limitations

- Insight scoring is a heuristic, not a statistically validated model.
- Correlation does not imply causation — the LLM is instructed to avoid causal
  claims unless explicitly supported by the finding.
- Anomaly detection (IQR-based) depends on the shape and size of the dataset;
  very small segments may not have enough points for reliable detection.
- Recommended actions are suggestions, not guaranteed causal conclusions.
- LLM output is constrained by, and only as good as, the structured analytical
  evidence it is given.

## Future Enhancements (not implemented)

- Forecasting
- More advanced anomaly detection (e.g. Isolation Forest, seasonal decomposition)
- Domain-specific business rules
- Additional data source connectors
- Natural-language Q&A over the dataset
- More sophisticated driver/root-cause analysis

## Project Structure

```
insight_generation/
├── app.py
├── requirements.txt
├── .env.example
├── README.md
├── data/
│   └── sample_data.csv       # synthetic/demo data
├── src/
│   ├── data_profiler.py
│   ├── data_processor.py
│   ├── analytics_engine.py
│   ├── insight_scorer.py
│   ├── llm_generator.py
│   ├── validator.py
│   └── utils.py
└── tests/
    └── test_pipeline.py
```
