"""
Central configuration and small shared helper functions.

Keeping all tunable thresholds in one place makes the heuristics easy
to explain and easy to change during a demo.
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class Config:
    # --- Trend analysis ---
    # Minimum absolute % change (period over period) for a trend to be
    # considered worth surfacing. Anything smaller is treated as noise.
    trend_min_pct_change: float = 5.0

    # --- Variance analysis ---
    # Minimum absolute % variance (actual vs benchmark) worth surfacing.
    variance_min_pct: float = 5.0

    # --- Contribution analysis ---
    # A segment must explain at least this % of the total change to be
    # reported as a "top contributor".
    contribution_min_pct: float = 10.0
    # If the total change is smaller (in absolute terms) than this,
    # contribution % is unstable (near-zero denominator) and is skipped.
    contribution_min_total_abs: float = 1e-6

    # --- Anomaly detection (IQR method) ---
    # Multiplier applied to the IQR to define the "normal" range.
    # 1.5 is the classic Tukey fence.
    anomaly_iqr_multiplier: float = 1.5
    # Minimum number of data points required per segment before we
    # attempt anomaly detection (too few points -> unreliable).
    anomaly_min_points: int = 5

    # --- Insight scoring weights (must sum to 1.0) ---
    weight_magnitude: float = 0.35
    weight_business_impact: float = 0.30
    weight_actionability: float = 0.20
    weight_novelty: float = 0.15

    # --- Dashboard ---
    max_insights_displayed: int = 8
    min_insights_displayed: int = 1

    # --- LLM ---
    llm_model: str = "gpt-4o-mini"
    llm_temperature: float = 0.2
    llm_max_findings_sent: int = 15  # cap number of LLM calls per run

    # Heuristics used by the data profiler to guess column roles.
    id_name_hints: List[str] = field(
        default_factory=lambda: ["id", "code", "key", "number", "no."]
    )
    date_name_hints: List[str] = field(
        default_factory=lambda: ["date", "month", "week", "year", "period", "day"]
    )


CONFIG = Config()


def safe_pct_change(current: float, previous: float) -> float:
    """
    Percentage change from `previous` to `current`.

    Returns 0.0 if `previous` is ~0 to avoid division-by-zero /
    exploding percentages that would mislead the LLM or the user.
    """
    if previous is None or abs(previous) < 1e-9:
        return 0.0
    return ((current - previous) / abs(previous)) * 100.0


def safe_div(numerator: float, denominator: float, default: float = 0.0) -> float:
    if denominator is None or abs(denominator) < 1e-9:
        return default
    return numerator / denominator


def direction_of(change: float) -> str:
    if change > 0:
        return "increase"
    if change < 0:
        return "decrease"
    return "flat"


def clamp(value: float, low: float = 0.0, high: float = 10.0) -> float:
    return max(low, min(high, value))
