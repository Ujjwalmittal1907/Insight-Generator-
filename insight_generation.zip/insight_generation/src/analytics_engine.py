"""
Analytics Engine
================
The core analytical logic. All numbers shown to the user (and later
sent to the LLM) are calculated here in plain Python/Pandas — the LLM
never invents or recalculates a number.

Four generators, each returning a list of "candidate finding" dicts:
    1. trend_analysis
    2. variance_analysis
    3. contribution_analysis
    4. anomaly_detection

Every finding dict shares a common shape (see `_base_finding`) so the
scorer, validator, and LLM prompt can all rely on consistent fields.
"""

from typing import List, Dict, Any, Optional
import pandas as pd

from src.utils import CONFIG, safe_pct_change, safe_div, direction_of


def _base_finding(
    finding_type: str,
    metric: str,
    dimension: str,
    segment: str,
    current_value: float,
    comparison_value: float,
    change: float,
    change_pct: float,
    evidence: List[str],
    severity: str = "Medium",
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    finding = {
        "type": finding_type,
        "metric": metric,
        "dimension": dimension,
        "segment": segment,
        "current_value": round(float(current_value), 2),
        "comparison_value": round(float(comparison_value), 2),
        "change": round(float(change), 2),
        "change_pct": round(float(change_pct), 2),
        "direction": direction_of(change),
        "evidence": evidence,
        "severity": severity,
    }
    if extra:
        finding.update(extra)
    return finding


# ---------------------------------------------------------------------
# 1. TREND ANALYSIS
# ---------------------------------------------------------------------
def trend_analysis(
    df: pd.DataFrame,
    date_col: str,
    metric_col: str,
    dimension_col: Optional[str] = None,
    min_pct_change: float = None,
) -> List[Dict[str, Any]]:
    """
    Compares the most recent period to the previous period for the
    overall metric, and (if a dimension column is given) for each
    segment within that dimension.

    "Period" = whatever the finest granularity in the date column is
    (we group by calendar date as given; if the data is daily this is
    day-over-day, if monthly it's month-over-month, etc.)
    """
    min_pct_change = CONFIG.trend_min_pct_change if min_pct_change is None else min_pct_change
    findings: List[Dict[str, Any]] = []

    if date_col not in df.columns or metric_col not in df.columns:
        return findings

    clean = df.dropna(subset=[date_col, metric_col]).copy()
    if clean.empty:
        return findings

    def _trend_for(sub: pd.DataFrame, segment_label: str, dimension_label: str):
        series = sub.groupby(date_col)[metric_col].sum().sort_index()
        if len(series) < 2:
            return
        current_value = series.iloc[-1]
        previous_value = series.iloc[-2]
        change = current_value - previous_value
        change_pct = safe_pct_change(current_value, previous_value)
        if abs(change_pct) < min_pct_change:
            return
        evidence = [
            f"{metric_col} moved from {previous_value:.2f} to {current_value:.2f}",
            f"Percentage change: {change_pct:.2f}%",
        ]
        severity = "High" if abs(change_pct) >= 2 * min_pct_change else "Medium"
        findings.append(
            _base_finding(
                "trend",
                metric_col,
                dimension_label,
                segment_label,
                current_value,
                previous_value,
                change,
                change_pct,
                evidence,
                severity,
            )
        )

    _trend_for(clean, "Overall", "Overall")

    if dimension_col and dimension_col in clean.columns:
        for segment, sub in clean.groupby(dimension_col):
            _trend_for(sub, str(segment), dimension_col)

    return findings


# ---------------------------------------------------------------------
# 2. VARIANCE ANALYSIS
# ---------------------------------------------------------------------
def variance_analysis(
    df: pd.DataFrame,
    metric_col: str,
    dimension_col: Optional[str] = None,
    target_col: Optional[str] = None,
    date_col: Optional[str] = None,
    min_pct_variance: float = None,
) -> List[Dict[str, Any]]:
    """
    Compares actual metric values against a benchmark:
      1. target_col, if provided (Actual vs Target)
      2. else previous period (if date_col provided)
      3. else overall average across segments
    """
    min_pct_variance = CONFIG.variance_min_pct if min_pct_variance is None else min_pct_variance
    findings: List[Dict[str, Any]] = []

    if metric_col not in df.columns:
        return findings

    use_target = target_col and target_col in df.columns
    group_col = dimension_col if (dimension_col and dimension_col in df.columns) else None

    if group_col is None:
        return findings  # variance is only meaningful across segments here

    grouped = df.groupby(group_col)

    if use_target:
        benchmark_label = f"Target {metric_col}"
        agg = grouped[[metric_col, target_col]].sum()
        for segment, row in agg.iterrows():
            actual = row[metric_col]
            benchmark = row[target_col]
            change = actual - benchmark
            change_pct = safe_pct_change(actual, benchmark)
            if abs(change_pct) < min_pct_variance:
                continue
            evidence = [
                f"Actual {metric_col} = {actual:.2f}",
                f"{benchmark_label} = {benchmark:.2f}",
                f"Variance % = {change_pct:.2f}%",
            ]
            severity = "High" if abs(change_pct) >= 2 * min_pct_variance else "Medium"
            findings.append(
                _base_finding(
                    "variance",
                    metric_col,
                    group_col,
                    str(segment),
                    actual,
                    benchmark,
                    change,
                    change_pct,
                    evidence,
                    severity,
                    extra={"benchmark_type": "target"},
                )
            )
    else:
        # Fall back to comparing each segment's average to the overall average.
        overall_avg = df[metric_col].mean()
        agg = grouped[metric_col].mean()
        for segment, actual in agg.items():
            change = actual - overall_avg
            change_pct = safe_pct_change(actual, overall_avg)
            if abs(change_pct) < min_pct_variance:
                continue
            evidence = [
                f"{segment} average {metric_col} = {actual:.2f}",
                f"Overall average {metric_col} = {overall_avg:.2f}",
                f"Variance % = {change_pct:.2f}%",
            ]
            severity = "High" if abs(change_pct) >= 2 * min_pct_variance else "Medium"
            findings.append(
                _base_finding(
                    "variance",
                    metric_col,
                    group_col,
                    str(segment),
                    actual,
                    overall_avg,
                    change,
                    change_pct,
                    evidence,
                    severity,
                    extra={"benchmark_type": "overall_average"},
                )
            )

    return findings


# ---------------------------------------------------------------------
# 3. CONTRIBUTION ANALYSIS
# ---------------------------------------------------------------------
def contribution_analysis(
    df: pd.DataFrame,
    date_col: str,
    metric_col: str,
    dimension_col: str,
    min_contribution_pct: float = None,
) -> List[Dict[str, Any]]:
    """
    When the overall metric changes period-over-period, identify which
    segments of `dimension_col` contributed most to that change.
    """
    min_contribution_pct = (
        CONFIG.contribution_min_pct if min_contribution_pct is None else min_contribution_pct
    )
    findings: List[Dict[str, Any]] = []

    required = {date_col, metric_col, dimension_col}
    if not required.issubset(df.columns):
        return findings

    clean = df.dropna(subset=[date_col, metric_col, dimension_col]).copy()
    if clean.empty:
        return findings

    # Determine the two most recent periods.
    periods = sorted(clean[date_col].unique())
    if len(periods) < 2:
        return findings
    current_period, previous_period = periods[-1], periods[-2]

    pivot = (
        clean[clean[date_col].isin([previous_period, current_period])]
        .groupby([dimension_col, date_col])[metric_col]
        .sum()
        .unstack(fill_value=0)
    )
    if current_period not in pivot.columns or previous_period not in pivot.columns:
        return findings

    pivot["segment_change"] = pivot[current_period] - pivot[previous_period]
    total_change = pivot["segment_change"].sum()

    if abs(total_change) < CONFIG.contribution_min_total_abs:
        return findings  # denominator too close to zero -> contribution % unstable

    pivot["contribution_pct"] = safe_div(pivot["segment_change"], total_change, default=0.0) * 100

    # Sort by absolute contribution and keep the top contributors.
    top = pivot.reindex(pivot["contribution_pct"].abs().sort_values(ascending=False).index)

    for segment, row in top.iterrows():
        contribution_pct = row["contribution_pct"]
        if abs(contribution_pct) < min_contribution_pct:
            continue
        segment_change = row["segment_change"]
        evidence = [
            f"{segment} {metric_col} change = {segment_change:.2f}",
            f"Total {metric_col} change = {total_change:.2f}",
            f"Contribution = {contribution_pct:.2f}%",
        ]
        severity = "High" if abs(contribution_pct) >= 40 else "Medium"
        findings.append(
            _base_finding(
                "contribution",
                metric_col,
                dimension_col,
                str(segment),
                row[current_period],
                row[previous_period],
                segment_change,
                contribution_pct,
                evidence,
                severity,
                extra={
                    "segment_change": round(float(segment_change), 2),
                    "total_change": round(float(total_change), 2),
                    "contribution_pct": round(float(contribution_pct), 2),
                },
            )
        )

    return findings


# ---------------------------------------------------------------------
# 4. ANOMALY DETECTION (IQR method — simple & explainable)
# ---------------------------------------------------------------------
def anomaly_detection(
    df: pd.DataFrame,
    metric_col: str,
    dimension_col: Optional[str] = None,
    iqr_multiplier: float = None,
    min_points: int = None,
) -> List[Dict[str, Any]]:
    """
    Flags values that fall outside [Q1 - k*IQR, Q3 + k*IQR].
    Runs on the overall metric, and per-segment if dimension_col given.
    """
    iqr_multiplier = CONFIG.anomaly_iqr_multiplier if iqr_multiplier is None else iqr_multiplier
    min_points = CONFIG.anomaly_min_points if min_points is None else min_points
    findings: List[Dict[str, Any]] = []

    if metric_col not in df.columns:
        return findings

    def _detect(values: pd.Series, segment_label: str, dimension_label: str):
        values = values.dropna()
        if len(values) < min_points:
            return
        q1, q3 = values.quantile(0.25), values.quantile(0.75)
        iqr = q3 - q1
        if iqr == 0:
            return
        lower = q1 - iqr_multiplier * iqr
        upper = q3 + iqr_multiplier * iqr
        expected_range = f"{lower:.2f} to {upper:.2f}"
        outliers = values[(values < lower) | (values > upper)]
        median = values.median()
        for value in outliers:
            deviation_pct = safe_pct_change(value, median)
            severity = "High" if abs(deviation_pct) >= 50 else "Medium"
            evidence = [
                f"Value = {value:.2f}",
                f"Expected range = {expected_range}",
                f"Segment median = {median:.2f}",
            ]
            findings.append(
                _base_finding(
                    "anomaly",
                    metric_col,
                    dimension_label,
                    segment_label,
                    value,
                    median,
                    value - median,
                    deviation_pct,
                    evidence,
                    severity,
                    extra={"expected_range": expected_range},
                )
            )

    if dimension_col and dimension_col in df.columns:
        for segment, sub in df.groupby(dimension_col):
            _detect(sub[metric_col], str(segment), dimension_col)
    else:
        _detect(df[metric_col], "Overall", "Overall")

    return findings


def generate_all_findings(
    df: pd.DataFrame,
    date_col: Optional[str],
    metric_col: str,
    dimension_col: Optional[str],
    target_col: Optional[str],
    min_pct_change: float = None,
) -> List[Dict[str, Any]]:
    """Convenience wrapper that runs all four analytics modules."""
    findings: List[Dict[str, Any]] = []

    if date_col:
        findings += trend_analysis(df, date_col, metric_col, dimension_col, min_pct_change)

    if dimension_col:
        findings += variance_analysis(
            df, metric_col, dimension_col, target_col, date_col, min_pct_change
        )

    if date_col and dimension_col:
        findings += contribution_analysis(df, date_col, metric_col, dimension_col, min_pct_change)

    findings += anomaly_detection(df, metric_col, dimension_col)

    return findings
