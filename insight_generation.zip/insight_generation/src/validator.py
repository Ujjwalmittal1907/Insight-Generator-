"""
Validator
=========
Before an LLM-generated narrative is shown to the user, verify it
against the structured finding it was based on. If validation fails,
the app falls back to showing the raw structured finding instead of a
possibly-wrong narrative.

Three checks, kept intentionally simple:
    1. Numerical validation — every number the LLM states must appear
       (within rounding tolerance) among the numbers in the finding.
    2. Evidence validation — the narrative must reference the finding's
       metric and/or segment, so it isn't a generic, unrelated blurb.
    3. Logic validation — the narrative's stated direction (increase/
       decrease) must not contradict the finding's actual direction.
"""

import re
from typing import Dict, Any, List, Tuple

NUMBER_PATTERN = re.compile(r"-?\d+(?:\.\d+)?")

INCREASE_WORDS = ["increase", "increased", "rose", "grew", "growth", "up ", "gain", "improved"]
DECREASE_WORDS = ["decrease", "decreased", "declined", "decline", "fell", "drop", "dropped", "down ", "loss", "reduced"]


def _extract_numbers(text: str) -> List[float]:
    return [float(n) for n in NUMBER_PATTERN.findall(text or "")]


def _finding_numbers(finding: Dict[str, Any]) -> List[float]:
    """All numeric values that are legitimately part of this finding."""
    candidate_keys = [
        "current_value",
        "comparison_value",
        "change",
        "change_pct",
        "segment_change",
        "total_change",
        "contribution_pct",
    ]
    numbers = []
    for key in candidate_keys:
        if key in finding and finding[key] is not None:
            try:
                numbers.append(round(float(finding[key]), 0))  # tolerant, integer-level match
            except (TypeError, ValueError):
                continue
    return numbers


def _numbers_match(stated: float, allowed: List[float], tolerance: float = 1.0) -> bool:
    """
    Checks whether `stated` is close to any number that legitimately
    belongs to the finding. Tolerance absorbs rounding differences
    (e.g. LLM writing "60%" for a 60.34% contribution).

    Narrative text naturally states magnitudes without a sign (e.g.
    "sales decreased by 12%" rather than "-12%"), so we compare
    absolute values. Sign/direction correctness is separately checked
    by validate_logic().
    """
    stated_abs = abs(stated)
    return any(
        abs(stated_abs - abs(allowed_val)) <= max(tolerance, abs(allowed_val) * 0.02)
        for allowed_val in allowed
    )


def validate_numbers(narrative_text: str, finding: Dict[str, Any]) -> Tuple[bool, List[float]]:
    """Returns (is_valid, list_of_unmatched_numbers)."""
    allowed = _finding_numbers(finding)
    stated_numbers = _extract_numbers(narrative_text)

    unmatched = []
    for num in stated_numbers:
        # Ignore tiny numbers like "1" or "2" used as list markers/counts,
        # they're rarely the substantive figures we care about.
        if abs(num) < 1:
            continue
        if not _numbers_match(num, allowed):
            unmatched.append(num)

    return (len(unmatched) == 0, unmatched)


def validate_evidence(narrative_text: str, finding: Dict[str, Any]) -> bool:
    """The narrative should mention the metric and/or the segment."""
    text_lower = (narrative_text or "").lower()
    metric = str(finding.get("metric", "")).lower()
    segment = str(finding.get("segment", "")).lower()
    mentions_metric = metric and metric in text_lower
    mentions_segment = segment and (segment in text_lower or segment == "overall")
    return bool(mentions_metric or mentions_segment)


def validate_logic(narrative_text: str, finding: Dict[str, Any]) -> bool:
    """The narrative's direction language should not contradict the finding."""
    text_lower = (narrative_text or "").lower()
    actual_direction = finding.get("direction")

    mentions_increase = any(word in text_lower for word in INCREASE_WORDS)
    mentions_decrease = any(word in text_lower for word in DECREASE_WORDS)

    if actual_direction == "increase" and mentions_decrease and not mentions_increase:
        return False
    if actual_direction == "decrease" and mentions_increase and not mentions_decrease:
        return False
    return True


def validate_narrative(narrative: Dict[str, Any], finding: Dict[str, Any]) -> Dict[str, Any]:
    """
    Runs all three checks against the combined narrative text.
    Returns:
        {
            "is_valid": bool,
            "failed_checks": [str, ...],
            "unmatched_numbers": [float, ...],
        }
    """
    if "error" in narrative:
        return {"is_valid": False, "failed_checks": ["llm_error"], "unmatched_numbers": []}

    combined_text = " ".join(
        [
            str(narrative.get("title", "")),
            str(narrative.get("what_happened", "")),
            str(narrative.get("why_it_matters", "")),
            str(narrative.get("recommended_action", "")),
        ]
    )

    failed_checks = []

    numbers_ok, unmatched = validate_numbers(combined_text, finding)
    if not numbers_ok:
        failed_checks.append("numerical_validation")

    if not validate_evidence(combined_text, finding):
        failed_checks.append("evidence_validation")

    if not validate_logic(combined_text, finding):
        failed_checks.append("logic_validation")

    return {
        "is_valid": len(failed_checks) == 0,
        "failed_checks": failed_checks,
        "unmatched_numbers": unmatched,
    }
