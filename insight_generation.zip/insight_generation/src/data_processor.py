"""
Data Processor
==============
Simple, safe preprocessing. Intentionally conservative: we do NOT
remove outliers here because the anomaly detector needs them.
"""

from typing import List, Dict, Any, Optional
import pandas as pd


def process_dataframe(
    df: pd.DataFrame,
    date_column: Optional[str] = None,
    numeric_columns: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Cleans a copy of `df` and returns:
        {
            "processed_df": cleaned DataFrame,
            "quality_report": { ... }
        }
    The original DataFrame is never mutated.
    """
    original_rows = len(df)
    processed = df.copy()

    # 1. Drop fully-empty rows.
    processed = processed.dropna(how="all")
    rows_after_empty_drop = len(processed)

    # 2. Drop exact duplicate rows.
    duplicates_removed = processed.duplicated().sum()
    processed = processed.drop_duplicates()

    # 3. Parse the date column, if provided.
    date_parse_failures = 0
    if date_column and date_column in processed.columns:
        parsed = pd.to_datetime(processed[date_column], errors="coerce")
        date_parse_failures = int(parsed.isna().sum() - processed[date_column].isna().sum())
        processed[date_column] = parsed

    # 4. Coerce numeric-looking columns to numeric (keeps NaN on failure
    #    rather than crashing).
    numeric_columns = numeric_columns or []
    for col in numeric_columns:
        if col in processed.columns:
            processed[col] = pd.to_numeric(processed[col], errors="coerce")

    quality_report = {
        "original_rows": original_rows,
        "rows_after_removing_empty": rows_after_empty_drop,
        "empty_rows_removed": original_rows - rows_after_empty_drop,
        "duplicate_rows_removed": int(duplicates_removed),
        "final_rows": len(processed),
        "date_parse_failures": date_parse_failures,
    }

    return {"processed_df": processed, "quality_report": quality_report}
