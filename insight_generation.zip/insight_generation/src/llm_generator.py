"""
LLM Generator
=============
Takes ONE structured finding (already calculated by analytics_engine.py)
and asks GPT-4o-mini to turn it into a business-friendly narrative.

The LLM is never given the raw dataset — only the finding + its
evidence strings. It must not invent numbers; the validator.py module
double-checks this afterward.
"""

import json
import os
from typing import Dict, Any, Optional

from openai import OpenAI
from dotenv import load_dotenv

from src.utils import CONFIG

load_dotenv()

SYSTEM_PROMPT = """You are a business insight writer for a data analytics platform.

You will be given a single structured "finding" that was already calculated
by a Python analytics engine (trend, variance, contribution, or anomaly
analysis). Your job is ONLY to explain it in clear business language.

Strict rules:
1. Explain what happened, in plain business terms.
2. Explain why it matters (business relevance).
3. Suggest one concise, reasonable recommended action.
4. NEVER change, round differently, or invent any numerical value.
   Only use numbers that appear in the finding provided to you.
5. NEVER invent data, segments, or comparisons that are not in the finding.
6. NEVER claim causation ("X caused Y") unless the finding explicitly
   supports it — prefer language like "may be related to" or
   "warrants investigation".
7. Clearly separate evidence (what the data shows) from interpretation
   (what you think it means).
8. Use concise, professional business language. No fluff, no emojis.

Respond ONLY with a JSON object with exactly these keys:
{
  "title": "short headline (<= 12 words)",
  "what_happened": "1-2 sentences, factual, numbers must match the finding",
  "why_it_matters": "1-2 sentences of business interpretation",
  "recommended_action": "1 concise, actionable sentence",
  "confidence": "High" | "Medium" | "Low"
}
Do not include any text outside the JSON object.
"""


def _build_user_prompt(finding: Dict[str, Any]) -> str:
    payload = {
        "finding_type": finding.get("type"),
        "metric": finding.get("metric"),
        "dimension": finding.get("dimension"),
        "segment": finding.get("segment"),
        "current_value": finding.get("current_value"),
        "comparison_value": finding.get("comparison_value"),
        "change": finding.get("change"),
        "change_pct": finding.get("change_pct"),
        "direction": finding.get("direction"),
        "severity": finding.get("severity"),
        "supporting_evidence": finding.get("evidence", []),
    }
    # Include contribution-specific fields if present.
    for key in ("segment_change", "total_change", "contribution_pct", "expected_range"):
        if key in finding:
            payload[key] = finding[key]

    return (
        "Here is the structured finding:\n"
        + json.dumps(payload, indent=2)
        + "\n\nWrite the JSON insight now."
    )


def _get_client() -> Optional[OpenAI]:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None
    return OpenAI(api_key=api_key)


def generate_narrative(finding: Dict[str, Any]) -> Dict[str, Any]:
    """
    Calls GPT-4o-mini to turn a finding into a narrative insight.

    Returns a dict with the narrative fields, OR a dict with an "error"
    key if the API call fails (so the UI can fall back gracefully to
    displaying the raw structured finding).
    """
    client = _get_client()
    if client is None:
        return {"error": "OPENAI_API_KEY is not set. Add it to your .env file."}

    try:
        response = client.chat.completions.create(
            model=CONFIG.llm_model,
            temperature=CONFIG.llm_temperature,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": _build_user_prompt(finding)},
            ],
        )
        content = response.choices[0].message.content
        narrative = json.loads(content)
        required_keys = {"title", "what_happened", "why_it_matters", "recommended_action", "confidence"}
        if not required_keys.issubset(narrative.keys()):
            return {"error": "LLM response was missing required fields."}
        return narrative
    except json.JSONDecodeError:
        return {"error": "LLM did not return valid JSON."}
    except Exception as exc:  # noqa: BLE001 - surface any API failure to the UI
        return {"error": f"LLM call failed: {exc}"}
