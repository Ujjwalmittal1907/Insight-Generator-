"""
Insight Scorer
==============
A simple, transparent, CONFIGURABLE heuristic for ranking candidate
findings. This is NOT a statistically validated model — it's a
prioritization aid so the most interesting findings surface first.

Score = 0.35 * Magnitude + 0.30 * Business Impact
      + 0.20 * Actionability + 0.15 * Novelty   (each component 0-10)
"""

from typing import List, Dict, Any
from src.utils import CONFIG, clamp

# Metrics considered "high impact" by default. This is a simple,
# editable list — in a real deployment this might come from config
# or be user-selected in the sidebar.
DEFAULT_HIGH_IMPACT_METRICS = {"sales", "revenue", "target"}


def _score_magnitude(finding: Dict[str, Any]) -> float:
    pct = abs(finding.get("change_pct", 0))
    # Scale: 0% -> 0, 100%+ -> 10 (soft cap)
    return clamp(pct / 10.0)


def _score_business_impact(finding: Dict[str, Any], high_impact_metrics=None) -> float:
    high_impact_metrics = high_impact_metrics or DEFAULT_HIGH_IMPACT_METRICS
    metric = str(finding.get("metric", "")).lower()
    base = 7.0 if metric in high_impact_metrics else 5.0
    if finding.get("severity") == "High":
        base += 2.0
    return clamp(base)


def _score_actionability(finding: Dict[str, Any]) -> float:
    # Contribution and variance findings point clearly at a segment to
    # investigate -> more actionable. Anomalies are noteworthy but may
    # be one-off data issues -> slightly less actionable by default.
    type_scores = {
        "contribution": 8.0,
        "variance": 7.0,
        "trend": 6.0,
        "anomaly": 5.0,
    }
    return clamp(type_scores.get(finding.get("type"), 5.0))


def _score_novelty(finding: Dict[str, Any]) -> float:
    # Larger deviations from "normal" are more novel/noteworthy.
    if finding.get("type") == "anomaly":
        return clamp(8.0)
    pct = abs(finding.get("change_pct", 0))
    return clamp(pct / 15.0)


def score_finding(finding: Dict[str, Any]) -> Dict[str, Any]:
    """Attaches score components and a final weighted score to a finding."""
    magnitude = _score_magnitude(finding)
    business_impact = _score_business_impact(finding)
    actionability = _score_actionability(finding)
    novelty = _score_novelty(finding)

    total = (
        CONFIG.weight_magnitude * magnitude
        + CONFIG.weight_business_impact * business_impact
        + CONFIG.weight_actionability * actionability
        + CONFIG.weight_novelty * novelty
    )

    scored = dict(finding)
    scored["score_components"] = {
        "magnitude": round(magnitude, 2),
        "business_impact": round(business_impact, 2),
        "actionability": round(actionability, 2),
        "novelty": round(novelty, 2),
    }
    scored["insight_score"] = round(total, 2)
    return scored


def score_and_rank(findings: List[Dict[str, Any]], top_n: int = None) -> List[Dict[str, Any]]:
    """Scores all findings and returns them sorted, highest score first."""
    top_n = CONFIG.max_insights_displayed if top_n is None else top_n
    scored = [score_finding(f) for f in findings]
    scored.sort(key=lambda f: f["insight_score"], reverse=True)
    return scored[:top_n]
