"""
Data Profiler
=============
Automatically classifies columns into: numeric, categorical, date, or
possible-ID, and computes basic per-column statistics.

This uses simple, explainable heuristics (name hints + dtype checks +
cardinality checks) rather than trying to perfectly understand every
possible dataset. The user can always override the detected date
column in the UI.
"""

from typing import Dict, List, Any
import pandas as pd

from src.utils import CONFIG


def _looks_like_id(col_name: str, series: pd.Series, n_rows: int) -> bool:
    name_lower = col_name.lower()
    name_hint = any(hint in name_lower for hint in CONFIG.id_name_hints)
    if name_hint:
        return True
    # High-cardinality (near-unique) columns are also likely identifiers,
    # but only for integer/text columns. Continuous float metrics (e.g.
    # Sales = 1441.72) are naturally near-unique and are NOT ids.
    if pd.api.types.is_float_dtype(series):
        return False
    high_cardinality = n_rows > 0 and series.nunique(dropna=True) / n_rows > 0.9
    return high_cardinality and n_rows > 20


def _looks_like_date(col_name: str, series: pd.Series) -> bool:
    name_lower = col_name.lower()
    if any(hint in name_lower for hint in CONFIG.date_name_hints):
        return True
    if pd.api.types.is_datetime64_any_dtype(series):
        return True
    # Try a light-touch parse on a small sample to avoid false positives.
    sample = series.dropna().astype(str).head(20)
    if sample.empty:
        return False
    try:
        parsed = pd.to_datetime(sample, errors="coerce")
        return parsed.notna().mean() > 0.8
    except Exception:
        return False


def _col_stats(series: pd.Series) -> Dict[str, Any]:
    n = len(series)
    missing_pct = round((series.isna().sum() / n) * 100, 2) if n else 0.0
    stats = {
        "unique_values": int(series.nunique(dropna=True)),
        "missing_pct": missing_pct,
    }
    numeric_series = pd.to_numeric(series, errors="coerce")
    if numeric_series.notna().sum() > 0:
        stats.update(
            {
                "min": float(numeric_series.min()),
                "max": float(numeric_series.max()),
                "mean": float(numeric_series.mean()),
                "median": float(numeric_series.median()),
            }
        )
    return stats


def profile_dataframe(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Returns a profile dict:
    {
        "numeric_columns": [...],
        "categorical_columns": [...],
        "date_columns": [...],
        "id_columns": [...],
        "column_stats": {col: {...}},
        "n_rows": int,
        "n_cols": int,
    }
    """
    n_rows, n_cols = df.shape

    numeric_columns: List[str] = []
    categorical_columns: List[str] = []
    date_columns: List[str] = []
    id_columns: List[str] = []
    column_stats: Dict[str, Any] = {}

    for col in df.columns:
        series = df[col]
        column_stats[col] = _col_stats(series)

        if _looks_like_id(col, series, n_rows):
            id_columns.append(col)
            continue

        if _looks_like_date(col, series):
            date_columns.append(col)
            continue

        # Numeric check: dtype is numeric, or a large share of non-null
        # values can be coerced to numeric.
        if pd.api.types.is_numeric_dtype(series):
            numeric_columns.append(col)
            continue

        coerced = pd.to_numeric(series, errors="coerce")
        non_null = series.notna().sum()
        if non_null > 0 and coerced.notna().sum() / non_null > 0.9:
            numeric_columns.append(col)
            continue

        categorical_columns.append(col)

    return {
        "numeric_columns": numeric_columns,
        "categorical_columns": categorical_columns,
        "date_columns": date_columns,
        "id_columns": id_columns,
        "column_stats": column_stats,
        "n_rows": n_rows,
        "n_cols": n_cols,
    }


def missing_value_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Returns a small DataFrame summarizing missing values per column."""
    missing_count = df.isna().sum()
    missing_pct = (missing_count / len(df) * 100).round(2) if len(df) else missing_count
    summary = pd.DataFrame(
        {
            "column": df.columns,
            "missing_count": missing_count.values,
            "missing_pct": missing_pct.values,
        }
    )
    return summary.sort_values("missing_count", ascending=False).reset_index(drop=True)
