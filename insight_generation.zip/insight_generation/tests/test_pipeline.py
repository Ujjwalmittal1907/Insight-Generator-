"""
Basic test suite for Insight Generation.

Run with:
    pytest tests/test_pipeline.py -v
"""

import sys
import os
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.analytics_engine import trend_analysis, variance_analysis, contribution_analysis
from src.utils import safe_pct_change
from src.validator import validate_numbers, validate_logic


def test_trend_growth_pct():
    # 100 -> 120 should be +20% growth
    assert round(safe_pct_change(120, 100), 2) == 20.0


def test_trend_analysis_detects_growth():
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-02-01"],
            "Sales": [100, 120],
        }
    )
    df["Date"] = pd.to_datetime(df["Date"])
    findings = trend_analysis(df, "Date", "Sales", min_pct_change=5)
    assert len(findings) == 1
    assert findings[0]["change_pct"] == 20.0
    assert findings[0]["direction"] == "increase"


def test_variance_actual_vs_target():
    # Actual = 80, Target = 100 -> -20% variance
    df = pd.DataFrame(
        {
            "Region": ["A", "A", "B", "B"],
            "Sales": [40, 40, 60, 60],
            "Target": [50, 50, 60, 60],
        }
    )
    findings = variance_analysis(df, "Sales", dimension_col="Region", target_col="Target", min_pct_variance=5)
    region_a = [f for f in findings if f["segment"] == "A"]
    assert len(region_a) == 1
    assert round(region_a[0]["change_pct"], 2) == -20.0


def test_contribution_analysis():
    # Total change = -100, Segment A change = -60 -> 60% contribution
    df = pd.DataFrame(
        {
            "Date": ["2024-01-01"] * 2 + ["2024-02-01"] * 2,
            "Region": ["A", "B", "A", "B"],
            "Sales": [200, 100, 140, 60],  # A: 200->140 (-60), B: 100->60 (-40), total -100
        }
    )
    df["Date"] = pd.to_datetime(df["Date"])
    findings = contribution_analysis(df, "Date", "Sales", "Region", min_contribution_pct=10)
    region_a = [f for f in findings if f["segment"] == "A"]
    assert len(region_a) == 1
    assert round(region_a[0]["contribution_pct"], 2) == 60.0


def test_validate_numbers_rejects_incorrect_claim():
    finding = {
        "current_value": 88,
        "comparison_value": 100,
        "change": -12,
        "change_pct": -12,
    }
    # Correct claim: should validate
    good_text = "Sales decreased by 12%."
    is_valid, unmatched = validate_numbers(good_text, finding)
    assert is_valid

    # Incorrect claim: a number not in the finding
    bad_text = "Sales decreased by 45%."
    is_valid, unmatched = validate_numbers(bad_text, finding)
    assert not is_valid
    assert 45.0 in unmatched


def test_validate_logic_rejects_contradiction():
    finding = {"direction": "decrease"}
    contradictory_text = "Sales increased significantly this period."
    assert validate_logic(contradictory_text, finding) is False

    consistent_text = "Sales decreased significantly this period."
    assert validate_logic(consistent_text, finding) is True
