"""
Insight Generation — Streamlit App
===================================
AI-Powered Business Insight Discovery.

Pipeline:
  Upload -> Profile -> Process -> Analytics -> Score -> LLM -> Validate -> Dashboard

Run with:
    streamlit run app.py
"""

import os
import pandas as pd
import plotly.express as px
import streamlit as st
from dotenv import load_dotenv

from src.data_profiler import profile_dataframe, missing_value_summary
from src.data_processor import process_dataframe
from src.analytics_engine import generate_all_findings
from src.insight_scorer import score_and_rank
from src.llm_generator import generate_narrative
from src.validator import validate_narrative
from src.utils import CONFIG

load_dotenv()

st.set_page_config(page_title="Insight Generation", layout="wide")


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def load_file(uploaded_file) -> pd.DataFrame:
    name = uploaded_file.name.lower()
    if name.endswith(".csv"):
        return pd.read_csv(uploaded_file)
    elif name.endswith(".xlsx") or name.endswith(".xls"):
        return pd.read_excel(uploaded_file)
    else:
        raise ValueError("Unsupported file type. Please upload a .csv or .xlsx file.")


def severity_badge(severity: str) -> str:
    colors = {"High": "🔴 HIGH PRIORITY", "Medium": "🟠 MEDIUM PRIORITY", "Low": "🟢 LOW PRIORITY"}
    return colors.get(severity, severity)


def render_insight_card(scored_finding: dict, narrative: dict, validation: dict):
    with st.container(border=True):
        st.markdown(f"**{severity_badge(scored_finding.get('severity'))}**")

        if validation["is_valid"] and "error" not in narrative:
            st.subheader(narrative.get("title", "Insight"))
            st.markdown(f"**What happened?**  \n{narrative.get('what_happened', '')}")
            st.markdown(f"**Why it matters?**  \n{narrative.get('why_it_matters', '')}")
            st.markdown("**Supporting Evidence**")
            for item in scored_finding.get("evidence", []):
                st.markdown(f"- {item}")
            st.markdown(f"**Recommended Action**  \n{narrative.get('recommended_action', '')}")
            confidence = narrative.get("confidence", "Medium")
        else:
            # Fallback: validation failed or LLM error -> show raw finding.
            reason = ", ".join(validation.get("failed_checks", [])) or narrative.get("error", "unknown")
            st.warning(
                f"Narrative could not be validated ({reason}). Showing the underlying structured finding instead."
            )
            st.markdown(
                f"**{scored_finding['type'].title()} — {scored_finding['metric']} "
                f"({scored_finding['segment']})**"
            )
            st.markdown("**Evidence**")
            for item in scored_finding.get("evidence", []):
                st.markdown(f"- {item}")
            confidence = "Unverified"

        col1, col2 = st.columns(2)
        col1.metric("Insight Score", f"{scored_finding['insight_score']:.1f} / 10")
        col2.metric("Confidence", confidence)


# ---------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------
st.title("📊 Insight Generation")
st.caption("AI-Powered Business Insight Discovery")

if not os.getenv("OPENAI_API_KEY"):
    st.info(
        "No OPENAI_API_KEY found in your environment. You can still run the analytics "
        "pipeline; narrative generation will show structured findings instead of LLM text. "
        "Add a key to `.env` (see `.env.example`) to enable narratives.",
        icon="🔑",
    )

# ---------------------------------------------------------------------
# Sidebar — upload + configuration
# ---------------------------------------------------------------------
st.sidebar.header("1. Upload Dataset")
uploaded_file = st.sidebar.file_uploader("CSV or Excel file", type=["csv", "xlsx", "xls"])

use_sample = st.sidebar.checkbox("Use bundled synthetic sample dataset", value=uploaded_file is None)

df = None
load_error = None

if uploaded_file is not None and not use_sample:
    try:
        df = load_file(uploaded_file)
    except Exception as exc:
        load_error = str(exc)
elif use_sample:
    sample_path = os.path.join("data", "sample_data.csv")
    if os.path.exists(sample_path):
        df = pd.read_csv(sample_path)
    else:
        load_error = "Sample dataset not found at data/sample_data.csv."

if load_error:
    st.error(load_error)
    st.stop()

if df is None:
    st.info("Upload a CSV/Excel file or check 'Use bundled synthetic sample dataset' to get started.")
    st.stop()

if df.empty:
    st.error("The uploaded file has no rows. Please upload a non-empty dataset.")
    st.stop()

# ---------------------------------------------------------------------
# Profiling
# ---------------------------------------------------------------------
profile = profile_dataframe(df)

st.sidebar.header("2. Configure Analysis")

date_options = ["(none)"] + profile["date_columns"] + [
    c for c in df.columns if c not in profile["date_columns"]
]
default_date = profile["date_columns"][0] if profile["date_columns"] else "(none)"
date_col_choice = st.sidebar.selectbox(
    "Date column", options=date_options, index=date_options.index(default_date)
)
date_col = None if date_col_choice == "(none)" else date_col_choice

if not profile["numeric_columns"]:
    st.error(
        "No numeric columns were detected in this dataset. Insight Generation needs at least "
        "one numeric metric (e.g. Sales, Revenue) to analyze."
    )
    st.stop()

metric_col = st.sidebar.selectbox("Primary metric", options=profile["numeric_columns"])

target_options = ["(none)"] + [c for c in profile["numeric_columns"] if c != metric_col]
target_col_choice = st.sidebar.selectbox("Target column (optional)", options=target_options)
target_col = None if target_col_choice == "(none)" else target_col_choice

dimension_options = ["(none)"] + profile["categorical_columns"]
dimension_col_choice = st.sidebar.selectbox(
    "Key dimension (e.g. Region)", options=dimension_options,
    index=1 if profile["categorical_columns"] else 0,
)
dimension_col = None if dimension_col_choice == "(none)" else dimension_col_choice

min_change_threshold = st.sidebar.slider(
    "Minimum change threshold (%)", min_value=1, max_value=50,
    value=int(CONFIG.trend_min_pct_change), step=1,
)

num_insights = st.sidebar.slider(
    "Number of insights to show", min_value=1, max_value=15,
    value=CONFIG.max_insights_displayed,
)

generate_clicked = st.sidebar.button("🚀 Generate Insights", type="primary")

# ---------------------------------------------------------------------
# Dataset overview
# ---------------------------------------------------------------------
st.header("Dataset Overview")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Rows", profile["n_rows"])
c2.metric("Columns", profile["n_cols"])
if date_col and date_col in df.columns:
    try:
        parsed_dates = pd.to_datetime(df[date_col], errors="coerce")
        date_range = f"{parsed_dates.min().date()} → {parsed_dates.max().date()}"
    except Exception:
        date_range = "N/A"
else:
    date_range = "N/A"
c3.metric("Date Range", date_range)
c4.metric("Segments" if dimension_col else "Dimension", df[dimension_col].nunique() if dimension_col else "N/A")

with st.expander("Preview data"):
    st.dataframe(df.head(20), use_container_width=True)
    st.markdown(
        f"**Detected column types** — Numeric: `{profile['numeric_columns']}` | "
        f"Categorical: `{profile['categorical_columns']}` | Date: `{profile['date_columns']}` | "
        f"Possible ID: `{profile['id_columns']}`"
    )

# ---------------------------------------------------------------------
# Data quality
# ---------------------------------------------------------------------
st.header("Data Quality")
missing_df = missing_value_summary(df)
dq1, dq2 = st.columns([2, 1])
with dq1:
    st.dataframe(missing_df, use_container_width=True, hide_index=True)
with dq2:
    st.metric("Duplicate Rows", int(df.duplicated().sum()))
    st.metric("Total Missing Cells", int(df.isna().sum().sum()))

# ---------------------------------------------------------------------
# Run pipeline on click
# ---------------------------------------------------------------------
if generate_clicked:
    if len(df) < 5:
        st.error("This dataset has too few rows for reliable analysis (minimum 5 recommended).")
        st.stop()

    with st.spinner("Processing data..."):
        processing_result = process_dataframe(
            df, date_column=date_col, numeric_columns=profile["numeric_columns"]
        )
        processed_df = processing_result["processed_df"]
        quality_report = processing_result["quality_report"]

    st.subheader("Processing Summary")
    pq1, pq2, pq3, pq4 = st.columns(4)
    pq1.metric("Original Rows", quality_report["original_rows"])
    pq2.metric("Empty Rows Removed", quality_report["empty_rows_removed"])
    pq3.metric("Duplicates Removed", quality_report["duplicate_rows_removed"])
    pq4.metric("Final Rows", quality_report["final_rows"])
    if quality_report["date_parse_failures"]:
        st.warning(f"{quality_report['date_parse_failures']} date values could not be parsed and were set to missing.")

    with st.spinner("Running analytics engine (trend, variance, contribution, anomaly)..."):
        findings = generate_all_findings(
            processed_df,
            date_col=date_col,
            metric_col=metric_col,
            dimension_col=dimension_col,
            target_col=target_col,
            min_pct_change=min_change_threshold,
        )

    if not findings:
        st.warning(
            "No significant findings were detected with the current thresholds. Try lowering "
            "the minimum change threshold in the sidebar, or choose a different metric/dimension."
        )
        st.stop()

    st.success(f"Found {len(findings)} candidate finding(s) across trend, variance, contribution, and anomaly analysis.")

    with st.spinner("Scoring and ranking insights..."):
        ranked = score_and_rank(findings, top_n=num_insights)

    # KPI summary
    st.header("KPI Summary")
    k1, k2, k3 = st.columns(3)
    k1.metric(f"Total {metric_col}", f"{processed_df[metric_col].sum():,.0f}")
    k2.metric(f"Average {metric_col}", f"{processed_df[metric_col].mean():,.1f}")
    if target_col:
        k3.metric(f"Total {target_col}", f"{processed_df[target_col].sum():,.0f}")
    else:
        k3.metric("Candidate Findings", len(findings))

    # Charts
    st.header("Charts")
    chart_cols = st.columns(2)
    with chart_cols[0]:
        if date_col:
            trend_df = processed_df.dropna(subset=[date_col]).groupby(date_col)[metric_col].sum().reset_index()
            fig = px.line(trend_df, x=date_col, y=metric_col, title=f"{metric_col} Over Time", markers=True)
            st.plotly_chart(fig, use_container_width=True)
    with chart_cols[1]:
        if dimension_col:
            seg_df = processed_df.groupby(dimension_col)[metric_col].sum().reset_index().sort_values(
                metric_col, ascending=False
            )
            fig2 = px.bar(seg_df, x=dimension_col, y=metric_col, title=f"{metric_col} by {dimension_col}")
            st.plotly_chart(fig2, use_container_width=True)

    # Generate narratives + validate
    st.header(f"Top {len(ranked)} Insights")
    llm_limit = min(len(ranked), CONFIG.llm_max_findings_sent)

    for i, scored_finding in enumerate(ranked):
        with st.spinner(f"Generating narrative {i + 1}/{llm_limit}..."):
            narrative = generate_narrative(scored_finding)
            validation = validate_narrative(narrative, scored_finding)
        render_insight_card(scored_finding, narrative, validation)

else:
    st.info("Configure your analysis in the sidebar, then click **Generate Insights**.")

st.markdown("---")
st.caption(
    "Insight Generation — demo application. Insight scoring is a configurable heuristic, "
    "not a statistically validated model. Correlation does not imply causation."
)
